
#pragma once

#define HL2SS_ENABLE_RM  1
#define HL2SS_ENABLE_PV  2
#define HL2SS_ENABLE_MC  4
#define HL2SS_ENABLE_SI  8
#define HL2SS_ENABLE_RC 16
#define HL2SS_ENABLE_SM 32
#define HL2SS_ENABLE_SU 64
